// LocalStorage helpers
const saveData = (key, data) => localStorage.setItem(key, JSON.stringify(data));
const loadData = (key) => JSON.parse(localStorage.getItem(key)) || [];

// Switch Tabs
const tabs = document.querySelectorAll(".bottom-nav button");
const sections = document.querySelectorAll(".tab-section");

tabs.forEach(btn => {
  btn.addEventListener("click", () => {
    sections.forEach(sec => sec.classList.remove("active"));
    document.getElementById(btn.dataset.target).classList.add("active");
  });
});

// Driver Form
const driverForm = document.getElementById("driverForm");
const driverList = document.getElementById("driverList");
const rideSelect = document.getElementById("rideSelect");

let drivers = loadData("drivers");

const renderDrivers = () => {
  driverList.innerHTML = "";
  rideSelect.innerHTML = "<option value=''>Select Ride</option>";
  drivers.forEach((d, index) => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <strong>${d.name}</strong> (${d.vehicleNo})<br>
      ${d.fromCity} → ${d.toCity}<br>
      Pickup: ${d.pickupLocation} | Drop: ${d.dropLocation}<br>
      Time: ${d.departureTime}<br>
      Seats: ${d.seatsAvailable}<br>
      Fare: ₹${d.fare} (+₹${d.extraFare} for home service)
    `;
    driverList.appendChild(card);

    if (d.seatsAvailable > 0) {
      let option = document.createElement("option");
      option.value = index;
      option.textContent = `${d.fromCity} → ${d.toCity} (${d.seatsAvailable} seats)`;
      rideSelect.appendChild(option);
    }
  });
};

driverForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const newDriver = {
    name: driverForm.driverName.value,
    contact: driverForm.driverContact.value,
    vehicleNo: driverForm.vehicleNo.value,
    fromCity: driverForm.fromCity.value,
    toCity: driverForm.toCity.value,
    pickupLocation: driverForm.pickupLocation.value,
    dropLocation: driverForm.dropLocation.value,
    departureTime: driverForm.departureTime.value,
    seatsAvailable: parseInt(driverForm.seatsAvailable.value),
    fare: parseInt(driverForm.fare.value),
    extraFare: parseInt(driverForm.extraFare.value) || 0
  };
  drivers.push(newDriver);
  saveData("drivers", drivers);
  renderDrivers();
  driverForm.reset();
});

renderDrivers();

// Customer Form
const customerForm = document.getElementById("customerForm");
let bookings = loadData("bookings");
const bookingList = document.getElementById("bookingList");

const renderBookings = () => {
  bookingList.innerHTML = "";
  bookings.forEach(b => {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <strong>${b.customer}</strong> booked ${b.seats} seat(s)<br>
      Ride: ${b.fromCity} → ${b.toCity}<br>
      Pickup Near: ${b.landmark || "N/A"}<br>
      Status: ${b.status}
    `;
    bookingList.appendChild(card);
  });
};

customerForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const rideIndex = rideSelect.value;
  if (rideIndex === "") return alert("Please select a ride!");

  const ride = drivers[rideIndex];
  const seatsNeeded = parseInt(customerForm.seatsBooked.value);

  if (ride.seatsAvailable >= seatsNeeded) {
    ride.seatsAvailable -= seatsNeeded;

    const newBooking = {
      customer: customerForm.customerName.value,
      contact: customerForm.customerContact.value,
      seats: seatsNeeded,
      landmark: customerForm.landmark.value,
      fromCity: ride.fromCity,
      toCity: ride.toCity,
      status: "Confirmed"
    };

    bookings.push(newBooking);
    saveData("bookings", bookings);
    saveData("drivers", drivers);

    renderDrivers();
    renderBookings();
    customerForm.reset();
    alert("Booking Successful!");
  } else {
    alert("Not enough seats available!");
  }
});

renderBookings();